package com.selenium.pomeg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {
	
	//Create Locators
	By aboutLink = By.id("aboutLink");
	By contactLink = By.id("contactLink");
	
	
	public HomePage(WebDriver driver) {
		
	}
	
	//Constructor expects WebDriver as parameter

	
	//Methods to perform actions on above Web Elements


}


