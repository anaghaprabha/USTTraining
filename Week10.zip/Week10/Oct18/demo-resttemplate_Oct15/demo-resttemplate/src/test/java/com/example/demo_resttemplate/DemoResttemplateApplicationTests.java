package com.example.demo_resttemplate;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.annotation.Order;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.ResultHandler;
import org.springframework.test.web.servlet.ResultMatcher;

import com.fasterxml.jackson.databind.ObjectMapper;


import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.stream.Stream;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.*;
@SpringBootTest
@AutoConfigureMockMvc
class DemoResttemplateApplicationTests {

	@Autowired
	private MockMvc mockMvc;
	 
	@BeforeEach
	void met() {
		System.out.println("Before Each");
	}
	
//	private static Stream<Integer> fetchTicketIds(){
//		return Stream.of(8,9,13);
//		//
//	}
	
	/*private static Stream<Arguments> fetchTicketIds(){
		return Stream.of(
				Arguments.of(8,"Pala", "Tvm"),
				Arguments.of(9, "test","test4"),
				Arguments.of(13, "testFrom","testTo"));
		
	}*/
	
	

	@Order(1)
	//@Test
	@ParameterizedTest
	@MethodSource("fetchTicketIds")
	void testGetTicket(int ticketId, String fromPlace, String toPlace) throws Exception {
		ResultActions resultActions = mockMvc.perform(get("/redbus/"+ticketId))  //sending get request with URL
		.andExpect(status().isOk())  //httpstatus code is 200
				.andExpect(content().contentType(MediaType.APPLICATION_JSON)) //content type
				.andExpect(jsonPath("$.fromPlace").value(fromPlace))  //expected response
				.andExpect(jsonPath("$.toPlace").value(toPlace));
		
		String jsonResponse = resultActions.andReturn().getResponse().getContentAsString();
		System.out.println("jsonResponse: "+jsonResponse);
		
		ObjectMapper omapper = new ObjectMapper();
		Ticket ticket = omapper.readValue(jsonResponse, Ticket.class);

		System.out.println("From Place: "+ticket.getFromPlace());
		System.out.println("Ticket Details: "+ticket);
		
		
	}



//	@Test
//	void testGetInvalidTicketID() throws Exception {
//		mockMvc.perform(get("/redbus/90"))  //sending get request with URL
//		.andExpect(status().is5xxServerError());  //httpstatus code is 200
//		
//	}
	 @Disabled
	@Order(2)
	@Test
	void testBookTicket() throws Exception {
		mockMvc.perform(post("/redbus").contentType(MediaType.APPLICATION_JSON)
				.content("{\"fromPlace\":\"testFrom1\","
						+"\"toPlace\":\"testTo1\","
						+"\"email\":\"test1@test.com\","
						+"\"userName\":\"testuser1\","
						+"\"price\":4565.7}"))
		        .andExpect(status().isCreated())
		        .andDo(print())
		        .andExpect(content().contentType(MediaType.APPLICATION_JSON))
		        .andExpect(jsonPath("$.userName").value("testuser1"));
	}
	
   @Disabled
	@Order(3)
	@Test
	void testUpdateTicket() throws Exception {
		mockMvc.perform(put("/redbus/6").contentType(MediaType.APPLICATION_JSON)
				.content("{\"fromPlace\":\"testFrom\","
						+"\"toPlace\":\"testTo\","
						+"\"email\":\"test@test.com\","
						//+"\"userName\":\"testuser\","
						+"\"price\":8765.7}")).andExpect(status().isCreated())
		        .andExpect(content().contentType(MediaType.APPLICATION_JSON));
		       
	}
   @Disabled
	@Order(4)
	@Test
	void testCancelTicket() throws Exception {
		mockMvc.perform(delete("/redbus/20"))  //sending delete request with URL
		.andExpect(status().isOk());  //httpstatus code is 200
	}

}
