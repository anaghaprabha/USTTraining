package com.learning.day22;

import java.io.FileOutputStream;
import java.io.IOException;

import com.fasterxml.jackson.core.exc.StreamWriteException;
import com.fasterxml.jackson.databind.DatabindException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

//when no POJO class exists
public class WriteJSONEg2 {

	public static void main(String[] args) throws Exception {

		ObjectMapper omapper = new ObjectMapper();
		
		ObjectNode onode = omapper.createObjectNode();
		onode.put("name", "Anagha");
		onode.put("age", "34");
		
		FileOutputStream fos = new FileOutputStream("person1.json");
		omapper.writeValue(fos, onode);
		
		System.out.println("Updated to person1.json file");
	}

}
