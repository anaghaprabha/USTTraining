package com.learning.day21;

import java.util.Arrays;

public class Person {

	private String name;
	private int agee;
	private Address address [];
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAgee() {
		return agee;
	}
	public void setAgee(int agee) {
		this.agee = agee;
	}
	public Address [] getAddress() {
		return address;
	}
	public void setAddress(Address address[]) {
		this.address = address;
	}
	public Person(String name, int agee, Address address[]) {
		super();
		this.name = name;
		this.agee = agee;
		this.address = address;
	}
	
	public Person() {
		super();
	}
	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + agee + ", address=" + Arrays.toString(address) + "]";
	}
	
	
	
	
}
