package com.learning.day22;

import java.io.*;


import com.fasterxml.jackson.databind.*;



public class ReadJSONEg {

	public static void main(String[] args) throws Exception {
		
		ObjectMapper omapper = new ObjectMapper();
		FileInputStream fis = new FileInputStream("./person.json");
		
		
		Person person = omapper.readValue(fis, Person.class);
		
		System.out.println(person);
		
	}

}
