package com.learning.day23;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReadEg2 {

	public static void main(String[] args) {
		try {

			FileInputStream fis = new FileInputStream("D://SecondExcel.xls");
			Workbook wbook = new XSSFWorkbook(fis);
			System.out.println("No of sheets " + wbook.getNumberOfSheets());

			int sheetCount = wbook.getNumberOfSheets();

			for (int k = 0; k < sheetCount; k++) {

				Sheet sheet = wbook.getSheetAt(k);
				int rowCount = sheet.getPhysicalNumberOfRows();

				for (int i = 0; i < rowCount; i++) {
					Row row = sheet.getRow(i);
					for (int j = 0; j < row.getPhysicalNumberOfCells(); j++) {
						Cell cell = row.getCell(j);

						System.out.println(cell.getStringCellValue());
					}

				}
			}

		}

		catch (Exception e) {
			e.printStackTrace();
		}

	}
}
