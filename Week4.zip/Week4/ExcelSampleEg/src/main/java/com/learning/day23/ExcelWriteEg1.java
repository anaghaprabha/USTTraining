package com.learning.day23;

import java.io.FileOutputStream;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelWriteEg1 {

	static String sarr[][] = { { "abcefg", "cdefgh", "defghi" }, { "fghijkl", "hijklmn", "jklmnop" },
			{ "mnopqr", "pqrstu", "stuvwx" } };

	public static void main(String[] args) {
		try {
		Workbook wbook = new XSSFWorkbook();
		Sheet sheet = wbook.createSheet("FirstSheet");
		
		for(int i = 0; i<sarr.length; i++) {
			Row row = sheet.createRow(i);
			for(int j=0; j<sarr[0].length; j++) {
				System.out.print(sarr[i][j] + "\t");
				Cell cell = row.createCell(j);
				cell.setCellValue(sarr[i][j]);
			}System.out.println();
		}
		
		FileOutputStream fos = new FileOutputStream("D://SecondExcel.xls");
		
		wbook.write(fos);

	}
		catch(Exception e) {
			e.printStackTrace();
		}

}
}
