package com.learning.day23;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReadEg {

	
	public static void main(String[] args) {
		try {
			
			FileInputStream fis = new FileInputStream("D://SecondExcel.xls");
		Workbook wbook = new XSSFWorkbook(fis);
		System.out.println("No of sheets "+wbook.getNumberOfSheets());
		
		Sheet sheet = wbook.getSheetAt(0);
		
		Row row = sheet.getRow(0);
		
		Cell cell = row.getCell(0);
		
		System.out.println(cell.getStringCellValue());
		

	}
		catch(Exception e) {
			e.printStackTrace();
		}

}
}
