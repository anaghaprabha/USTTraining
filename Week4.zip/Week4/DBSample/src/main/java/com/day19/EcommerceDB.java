package com.day19;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

public class EcommerceDB {

	private static final String DRIVER_NAME = "com.mysql.cj.jdbc.Driver";
	private static final String CONNECTION_STRING = "jdbc:mysql://127.0.0.1:3306/ecommerce";
	private static final String USER = "root";
	private static final String PASSWORD = "pass@word1";

	public static void main(String[] args) {

		Connection connection = null;
		try {

			Class.forName(DRIVER_NAME);
			connection = DriverManager.getConnection(CONNECTION_STRING, USER, PASSWORD);

			Statement ps = connection.createStatement();

			ResultSet resultSet;
			resultSet = ps.executeQuery("select * from inventory");

			while (resultSet.next()) {
				int id = resultSet.getInt("product_id");
				String name = resultSet.getString("product_name").trim();
				String cat = resultSet.getString("product_category").trim();
				String spec = resultSet.getString("product_spec").trim();
				int qty = resultSet.getInt("product_quantity");
				System.out.println("Product ID : " + id + "| Name : " + name + " | Category: " + cat
						+ " | Specifications: " + spec + " | Quantity: " + qty);
			}
			resultSet.close();
			ps.close();
			connection.close();
		} catch (Exception exception) {
			System.out.println(exception);
		}

	}
}
