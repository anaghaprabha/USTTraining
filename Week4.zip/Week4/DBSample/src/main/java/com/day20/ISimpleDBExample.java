package com.day20;

// Develop a program to update given messages db table, to update Internal with I, and External with E?
import java.sql.*;

public class ISimpleDBExample {
	private static final String DRIVER_NAME = "com.mysql.cj.jdbc.Driver";
	private static final String UPDATE_QUERY = "UPDATE messages SET ptype = ? WHERE ptype = ?";

	public static void main(String arg[]) {
		Connection connection = null;
		try {
			// below two lines are used for connectivity.
			Class.forName(DRIVER_NAME);
			connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/sept2", "root", "pass@word1");

			// SQL
			PreparedStatement ps1 = connection.prepareStatement(UPDATE_QUERY);

			ps1.setString(1, "E");
			ps1.setString(2, "External");

			int records;
			records = ps1.executeUpdate();
			System.out.println("Updated " + records + " records successfully");

			ps1.setString(1, "I");
			ps1.setString(2, "Internal");

			records = ps1.executeUpdate();

			System.out.println("Updated " + records + " records successfully");
			ps1.close();

			connection.close();

		} catch (Exception exception) {
			System.out.println(exception);
		} finally {

		}
	} // function ends
} // class ends