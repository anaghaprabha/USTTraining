package com.learning.day21;

import java.io.*;
import com.fasterxml.jackson.databind.*;

public class WriteJSONEg {

	public static void main(String[] args) throws Exception {

       Address[] address = {new Address("street1", "city1", 689647),new Address("street2", "city2", 689645)};
		Person person = new Person("Anagha",34,address);
		
		
		 
		ObjectMapper mapper = new ObjectMapper();
		
		FileOutputStream fos = new FileOutputStream("person.json");
		mapper.writeValue(fos, person);
		String pjson = mapper.writeValueAsString(person);
        System.out.println("Created JSON file with content: "+pjson);
	}

}
