package com.learning.oct8;

public class MaxArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		float array[] = { 10, 9, 8, 7, 10.06f };
		float max = array[0];
		for (int i = 0; i < array.length; i++) {
			if (array[i] > max) {
				max = array[i];

			}
		}
		System.out.println("Maximum Value is " + max);
	}

}
