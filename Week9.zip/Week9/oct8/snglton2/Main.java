package com.learning.oct8.snglton2;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		try (Scanner scanner = new Scanner(System.in)) {
			System.out.println("Enter the number of values: ");
			int length = scanner.nextInt();
			float array[] = new float[length];
			for(int i=0; i<length; i++) {
				System.out.println("Enter the value in position "+i+" : ");
				array[i] = scanner.nextFloat();
			}
			
			FindMinValue minValue = new FindMinValue(array);
			
			System.out.println("Minimum value of the array is "+minValue.getMinValue(array));
			
			SingletonEg single1 = SingletonEg.getInstance(array);
			System.out.println("Single 1: "+single1.getMinValue(array));
			
			SingletonEg single2 = SingletonEg.getInstance(array);
			System.out.println("Single 2: "+single2.getMinValue(array));
			
			SingletonEg single3 = SingletonEg.getInstance(array);
			System.out.println("Single 3: "+single3.getMinValue(array));
			
		}
		
		
	
	}

}
