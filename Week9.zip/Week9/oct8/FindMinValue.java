package com.learning.oct8;

public class FindMinValue {
	

	private float array[];

	public FindMinValue(float[] array) {
		this.setArray(array);
	}

	public float getMinValue(float[] array) {
		float min = array[0];
		for (int i = 0; i < array.length; i++) {
			if (array[i] < min) {
				min = array[i];

			}
		}
		return min;
	}

	public float[] getArray() {
		return array;
	}

	public void setArray(float array[]) {
		this.array = array;
	}

}
