package com.learning.oct8;

import java.util.Arrays;
import java.util.Scanner;

public class MinAlphaString {
    public static void main(String[] args) {
    	
       
        
        try (Scanner scanner = new Scanner(System.in)) {
			System.out.println("Enter the number of values: ");
			int length = scanner.nextInt();
			 String[] strings = new String[length];
			for(int i=0; i<length; i++) {
				System.out.println("Enter the value in position "+i+" : ");
				strings[i] = scanner.next();
			}
			

        
        Arrays.sort(strings);

        
        String minString = strings[0];

        System.out.println("The alphabetically minimum string is: " + minString);
    }
}
}