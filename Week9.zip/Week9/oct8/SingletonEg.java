package com.learning.oct8;

public class SingletonEg {

	/*
	 * singleton - only one object can be create 1. Make constructor private 2.
	 * Create a static method for object creation 3. In above method, create object
	 * only if object not already created 4. use static member to find object
	 * already created
	 * 
	 */
	private float array[];
	private static boolean objectCreated = false;
	private static SingletonEg mObj;

	private SingletonEg(float[] array) {
		super();
		this.array = array;
	}

	public float[] getArray() {
		return array;
	}

	public void setArray(float[] array) {
		this.array = array;
	}

	public static SingletonEg getInstance(float array[]) {
		//SingletonEg obj = mObj;
		if (objectCreated == false) {
			mObj = new SingletonEg(array);
			objectCreated = true;
			
		}
		return mObj;

	}
	
	public float getMinValue(float[] array) {
		float min = array[0];
		for (int i = 0; i < array.length; i++) {
			if (array[i] < min) {
				min = array[i];

			}
		}
		return min;
	}

}
