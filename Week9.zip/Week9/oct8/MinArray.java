package com.learning.oct8;

public class MinArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		float array[] = { 10, 9, 8, 7, 10.06f };
		float min = array[0];
		for (int i = 0; i < array.length; i++) {
			if (array[i] < min) {
				min = array[i];

			}
		}
		System.out.println("Minimum Value is " + min);
	}

}
