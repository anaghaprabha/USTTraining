package com.example.jpaone2many.model;

import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.*;

@Entity
public class Customer {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column
	private String name;
	
	@OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Set<Order> sOrder = new HashSet<>();
	
	private Customer() {
		
	}
//	private Customer(Long id, String name, Set<Order> sOrder) {
//		super();
//		this.id = id;
//		this.name = name;
//		this.sOrder = sOrder;
//	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<Order> getsOrder() {
		return sOrder;
	}

	public void setsOrder(Set<Order> sOrder) {
		this.sOrder = sOrder;
	}
	

}
