package com.example.jpaone2many.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.* ;

import com.example.jpaone2many.model.Customer;
import com.example.jpaone2many.service.CustomerService;

@RestController //@Controller + @ResponseBody
@RequestMapping("/customer")
public class CustomerController {
	
	@Autowired
	private CustomerService cService;
	
	
	@GetMapping
	public ResponseEntity<List<Customer>> getAllCustomers(){
		List<Customer> customers = cService.getAllCustomers();
		return new ResponseEntity<>(customers, HttpStatus.OK);
		
	}
	
	@PostMapping
	public ResponseEntity<Customer> createCustomer(@RequestBody Customer customer){
		Customer newCustomer = cService.saveCustomer(customer);
		return new ResponseEntity<>(newCustomer, HttpStatus.CREATED);
		
	}

}
