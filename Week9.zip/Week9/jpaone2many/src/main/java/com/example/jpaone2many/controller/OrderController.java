package com.example.jpaone2many.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.* ;

import com.example.jpaone2many.model.Order;
import com.example.jpaone2many.service.OrderService;

@RestController //@Controller + @ResponseBody
@RequestMapping("/order")
public class OrderController {
	
	@Autowired
	private OrderService oService;
	
	
	@GetMapping
	public ResponseEntity<List<Order>> getAllCustomers(){
		List<Order> orders = oService.getAllOrders();
		return new ResponseEntity<>(orders, HttpStatus.OK);
		
	}
	
	@PostMapping
	public ResponseEntity<Order> createCustomer(@RequestBody Order order){
		Order newOrder = oService.saveOrder(order);
		return new ResponseEntity<>(newOrder, HttpStatus.CREATED);
		
	}

}
