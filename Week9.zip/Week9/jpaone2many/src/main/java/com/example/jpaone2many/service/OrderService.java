package com.example.jpaone2many.service;

import java.util.List;

import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.Service;

import com.example.jpaone2many.model.Order;
import com.example.jpaone2many.repository.OrderRepository;

@Service
public class OrderService {
	
	@Autowired
	private OrderRepository oRepo;

	
	//get all orders
    public List<Order> getAllOrders(){
    	return oRepo.findAll();
    }
	
	//save all orders
    public Order saveOrder(Order order){
    	return oRepo.save(order);
    }

}
