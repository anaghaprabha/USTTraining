package com.exampledb.productoct3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Productoct3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
