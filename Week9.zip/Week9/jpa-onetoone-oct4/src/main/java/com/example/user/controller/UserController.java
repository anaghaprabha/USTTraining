package com.example.user.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.user.model.Profile;
import com.example.user.model.User;
import com.example.user.service.UserService;

/*
 * TRACE - detailed debugging
 * DEBUG  - detailed info for developers.
 * INFO - information abt flow of application
 * WARN - possible harmful situations
 * ERROR - errors during execution
 * FATAL - may terminate application
 */

@RestController
@RequestMapping
 public class UserController {
	
    private static final Logger logger = LoggerFactory.getLogger(UserController.class);
    
    public UserController() {
    	logger.info("UserController() constructor invoked");
    }
	@Autowired
	private UserService uService;

	@GetMapping("/user/{userid}")
	public User getUser(@PathVariable long userid)
    {
    	User cUser = uService.getUser(userid);
    	logger.debug("Successfully fetched the user details");
			return cUser;

	}
	
	@GetMapping("/profile/{profid}")
	public Profile getProfile(@PathVariable long profid)
    {
    
    	logger.debug("Successfully fetched the profile details");
			return uService.getProfile(profid);

	}

	@PostMapping("/create")
	public User createProduct(@RequestBody User user) {
		User cUser = uService.createUser(user);
		logger.debug("User created successfully through POST request");
		logger.warn("User Object "+user);
		return cUser;
	}

}
