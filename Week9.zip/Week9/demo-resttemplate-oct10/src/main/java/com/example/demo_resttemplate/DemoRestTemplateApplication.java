package com.example.demo_resttemplate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan({"com.example.demo_ticket","com.controller"})
public class DemoRestTemplateApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoRestTemplateApplication.class, args);
	}

}
