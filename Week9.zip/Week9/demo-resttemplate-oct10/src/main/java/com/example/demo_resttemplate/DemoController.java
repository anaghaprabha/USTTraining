package com.example.demo_resttemplate;


import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/redbus")
public class DemoController {
	
	
	@GetMapping
	public ResponseEntity<Ticket> getTicket() {
		RestTemplate rClient = new RestTemplate();
		ResponseEntity<Ticket> rTicket = rClient.getForEntity("http://localhost:8080/ticket/1", Ticket.class);
		System.out.println("Received ticket : "+rTicket.getBody());
		return rTicket;
		
	}

}
