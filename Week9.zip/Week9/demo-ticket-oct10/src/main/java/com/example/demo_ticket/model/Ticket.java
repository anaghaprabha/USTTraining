package com.example.demo_ticket.model;




import jakarta.persistence.*;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.validation.constraints.*;
//Whatever needs to be updated /created in DB
@Entity
public class Ticket {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	@NotNull(message = "Username cannot be null")
	@Column
	private String userName;
	
	@NotNull
	@Column
	private String fromPlace;
	
	@NotNull
	@Column
	private String toPlace;
	
	@NotNull
	@Column
	private String email;
	
	@DecimalMin("99.9")
	@DecimalMax("10000")
	@Column
	private float price;
	
	@Column
	private String pincode;

	public int getId() {
		return id;
	}

	public Ticket() {
		super();
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getFromPlace() {
		return fromPlace;
	}

	public void setFromPlace(String fromPlace) {
		this.fromPlace = fromPlace;
	}

	public String getToPlace() {
		return toPlace;
	}

	public void setToPlace(String toPlace) {
		this.toPlace = toPlace;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public Ticket(int id, String userName, String fromPlace, String toPlace, String email, float price,
			String pincode) {
		super();
		this.id = id;
		this.userName = userName;
		this.fromPlace = fromPlace;
		this.toPlace = toPlace;
		this.email = email;
		this.price = price;
		this.pincode = pincode;
	}

	@Override
	public String toString() {
		return String.format("Ticket [id=%s, userName=%s, fromPlace=%s, toPlace=%s, email=%s, price=%s, pincode=%s]",
				id, userName, fromPlace, toPlace, email, price, pincode);
	}
	
	

}