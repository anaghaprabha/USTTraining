package com.example.demo_ticket.exception;

public class InvalidTicketIDException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidTicketIDException(String message) {
		super(message);
	}

}
