package com.example.demo_ticket.service;

import java.util.*;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo_ticket.exception.InvalidTicketIDException;
import com.example.demo_ticket.model.Ticket;
import com.example.demo_ticket.repository.TicketRepository;

@Service
public class TicketService {
//Automatically adding code for DB interactions
	@Autowired
	private TicketRepository ticketRepo; // Dependency injection => DI

	public Ticket getTicketServ(int ticketid) {
		Optional<Ticket> oticket = ticketRepo.findById(ticketid);
				System.out.println(oticket);
		return oticket.get();

	}

	public Ticket bookTicketServ(Ticket ticket) {
		return ticketRepo.save(ticket);

	}

	public Ticket updateTicketServ(int tid, Ticket ticket) {
		Ticket eTicket = ticketRepo.findById(tid).get();
		eTicket.setFromPlace(ticket.getFromPlace());
		eTicket.setToPlace(ticket.getFromPlace());
		eTicket.setPrice(ticket.getPrice());
		return ticketRepo.save(eTicket);

	}

	public Ticket cancelTicketServ(int tid) {
		Ticket ticket = ticketRepo.findById(tid).get();
		ticketRepo.deleteById(tid);
		return ticket;

	}

	public Collection<Ticket> getAllTicketsRepo() {
		return ticketRepo.findAll();
	}
}
