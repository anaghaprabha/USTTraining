package com.example.demo_resttemplate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/redbus")
public class DemoController {

	@Autowired
	private DemoClientService clientService;

	@GetMapping("/{ticketid}")
	public ResponseEntity<Ticket> getTicket(@PathVariable int ticketid) {
		ResponseEntity<Ticket> reticket = clientService.getTicket(ticketid);
		System.out.println("Received Ticket:" + reticket.getBody());
		return reticket;
	}

	@PostMapping
	public ResponseEntity<Ticket> createTicket(@RequestBody Ticket ticket) {
		ResponseEntity<Ticket> reticket = clientService.createTicket(ticket);
		System.out.println("Created Ticket:" + reticket.getBody());
		return reticket;
	}

	@PutMapping("/{ticketid}")
	public ResponseEntity<Ticket> updateTicket(@PathVariable int ticketid, @RequestBody Ticket ticket) {
		ResponseEntity<Ticket> reticket = clientService.updateTicket(ticketid, ticket);
		System.out.println("Updated Ticket:" + reticket.getBody());
		return reticket;

	}

	@DeleteMapping("/{ticketid}")
	public Integer cancelTicket(@PathVariable int ticketid) {
		clientService.cancelTicket(ticketid);
		System.out.println("Cancelled Ticket with id: "+ticketid);
		return ticketid;

	}

}
