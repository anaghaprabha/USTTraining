package com.example.demo_resttemplate;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.*;
import org.springframework.test.web.servlet.*;

//import static java.lang.System.*;
@SpringBootTest
@AutoConfigureMockMvc
class DemoResttemplateApplicationTests {
	@Autowired
	private MockMvc mockMvc;

	private static Workbook wbook;

	private static Sheet sheet;

	private static int testCaseNo;

	@BeforeAll
	static void metb() {
	    // open or create excel(Test Report)
		// create workbook
		wbook = new XSSFWorkbook();
		// create a new sheet
		sheet = wbook.createSheet("FirstSheet");
		testCaseNo = 0;

	}

	@BeforeEach
	void met() {
		//testCaseNo++;
	}

	private static Stream<Arguments> fetchTicketIds() {
		List<Arguments> args = new ArrayList<>();
		try {
			// read from excel
			FileInputStream fis = new FileInputStream("D:\\Book.xlsx");

			// read workbook
			Workbook wbook = new XSSFWorkbook(fis);

			double value = 0;

			int no_of_rows = 0;
			Sheet st = null;

			// read sheet
			st = wbook.getSheetAt(0);
	// fetch number of rows in excel
			no_of_rows = st.getPhysicalNumberOfRows();

			for (int i = 0; i < no_of_rows; i++) {
				// read rows
				Row row = st.getRow(i);

				int no_of_cols = row.getLastCellNum();

				// read first column - ticket id
				Cell cell1 = row.getCell(0);

				int ticketid = (int) cell1.getNumericCellValue();
// read second col - fromplace
				Cell cell2 = row.getCell(1);
				String fromplace = cell2.getStringCellValue();
// read third col - toplace
				Cell cell3 = row.getCell(2);
				String toplace = cell3.getStringCellValue();

				Cell cell4 = row.getCell(3);
				float price = (float) cell4.getNumericCellValue();

				args.add(Arguments.of(ticketid, fromplace, toplace, price));
			}

			wbook.close();
			fis.close();

		} catch (Exception e) {

			System.out.println("Exceptionnnn" + e.getMessage());
			e.printStackTrace();
		}
// create and return Stream from List of JUnit Arguments
		return args.stream();
	}

	@ParameterizedTest
	@MethodSource("fetchTicketIds")
	void testGetTicket(int ticketid, String fromplace, String toplace, float price) throws Exception {
		try {
			ResultActions resultActions = mockMvc.perform(get("/redbus/" + ticketid)) // Sending GET request with url
					.andExpect(status().isOk()) // checking response Http Status code
					// below, checking response Content Type
					.andExpect(content().contentType(MediaType.APPLICATION_JSON))
					.andExpect(jsonPath("$.fromPlace").value(fromplace)).andExpect(jsonPath("$.toPlace").value(toplace))
					.andExpect(jsonPath("$.price").value(price));
			// .andDo(print());

			String jsonresponse = resultActions.andReturn().getResponse().getContentAsString();

			System.out.println("Json Responsee:" + jsonresponse);

			
			// json string to java object
			ObjectMapper omapper = new ObjectMapper();

			Ticket ticket = omapper.readValue(jsonresponse, Ticket.class);

			System.out.println("From Placeee:" + ticket.getFromPlace());
			System.out.println("Priceeeee:" + ticket.getPrice());

		} catch (AssertionError ae) {
			createTestResultsRow("Test Case Failed");
			System.out.println("Test Case Failed\n" + ae.getMessage());

			throw ae;
		} catch (Exception e) {

			System.out.println("Exception" + e.getMessage());

		}
		createTestResultsRow("Test Case Passed");
		System.out.println("Test Case Passed");

		System.out.println("****************************************");
	}
	
	private void createTestResultsRow(String result) {
		Row row = sheet.createRow(testCaseNo);
		testCaseNo++;
		Cell cell1 = row.createCell(0, CellType.NUMERIC);
		cell1.setCellValue(testCaseNo);
		Cell cell2 = row.createCell(1, CellType.STRING);
		cell2.setCellValue(result);
		 
		
	}

	@AfterEach
	void metae() {
		
	}

	@AfterAll
	static void meta() {
		//close the excel
		try {
			FileOutputStream fos = new FileOutputStream("./report.xlsx");
		
		wbook.write(fos);
		wbook.close();
		fos.close();
		}
		catch (Exception e) {
			System.out.println("Exception " + e.getMessage());

		}

	}

	// id which doesnt exist
	// not int id

	// @Test
	@Disabled
	void testBookTicket() throws Exception {
		mockMvc.perform(post("/redbus").contentType(MediaType.APPLICATION_JSON)
				.content("{\"username\":\"user456\"," + "\"fromplace\":\"tuvw\"," + "\"toplace\":\"klmn\","
						+ "\"email\":\"987652@gmail.com\", " + "\"price\":9876.5}"))
				.andExpect(status().isCreated()).andExpect(content().contentType(MediaType.APPLICATION_JSON))
				.andDo(print()).andExpect(jsonPath("$.username").value("user456"));
	}

	// @Test
	@Disabled
	void testUpdateTicket() throws Exception {
		mockMvc.perform(put("/redbus/27").contentType(MediaType.APPLICATION_JSON).content(
				// "{\"username\":\"user456\","+
				"{\"fromplace\":\"jjjjjj\"," + "\"toplace\":\"kkkk\"," + "\"email\":\"987652@gmail.com\", "
						+ "\"price\":9876.5}"))
				.andExpect(status().isCreated());
	}

	// @Test
	@Disabled
	void cancelTicket() throws Exception {
		mockMvc.perform(delete("/redbus/27")).andExpect(status().isOk());

	}

}
