package com.learning.day17;

public class InvalidPlanException extends Exception {

	String message;
	public InvalidPlanException(String message) {
		super();
	}

	

}
