package com.learning.day11;

public class InnerClassEg {

	class Q {}  // class inside a class
	
	void met() {
		class P {}  // class in a method
	}

	public static void main(String[] args) {
		
	}
}


