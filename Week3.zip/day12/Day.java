package com.learning.day12;

public enum Day {
	
		 MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY
		
}
